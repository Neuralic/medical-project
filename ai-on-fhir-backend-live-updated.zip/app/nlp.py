import re
import json
from datetime import date
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parents[1] / "data"

def load_icd_map():
    with open(DATA_DIR / "icd10_map.json") as f:
        icd = json.load(f)
    syn_to_key = {}
    for key, entry in icd.items():
        for s in entry.get("synonyms", []):
            syn_to_key[s.lower()] = key
    return icd, syn_to_key

ICD10, SYN_TO_KEY = load_icd_map()

COMPARATORS = {
    "over": "gt",
    "older than": "gt",
    "greater than": "gt",
    "more than": "gt",
    "above": "gt",
    "under": "lt",
    "younger than": "lt",
    "less than": "lt",
    "below": "lt",
    "at least": "ge",
    "at most": "le",
    "equals": "eq",
    "equal to": "eq",
    "exactly": "eq"
}

def extract_age_constraint(text: str):
    t = text.lower()
    for phrase, op in sorted(COMPARATORS.items(), key=lambda x: -len(x[0])):
        if phrase in t:
            m = re.search(rf"{re.escape(phrase)}\s*(\d+)", t)
            if m:
                return {"op": op, "value": int(m.group(1))}
    m = re.search(r"(?:over|above|under|below|age|aged)?\s*(\d{1,3})\s*\+?", t)
    if m:
        if "+" in t or "over" in t or "above" in t:
            return {"op": "ge" if "+" in t else "gt", "value": int(m.group(1))}
        if "under" in t or "below" in t:
            return {"op": "lt", "value": int(m.group(1))}
        return {"op": "eq", "value": int(m.group(1))}
    return None

def extract_gender(text: str):
    t = text.lower()
    if "female" in t or "women" in t or "woman" in t:
        return "female"
    if "male" in t or "men" in t or "man" in t:
        return "male"
    return None

def extract_condition(text: str):
    t = text.lower()
    for syn, key in SYN_TO_KEY.items():
        if re.search(rf"\\b{re.escape(syn)}\\b", t):
            entry = ICD10[key]
            return {"text": syn, "icd10": entry["code"], "display": entry["display"], "system": entry["system"]}
    return None

def age_to_birthdate_filter(op: str, years: int):
    today = date.today()
    try:
        boundary = date(today.year - years, today.month, today.day)
    except Exception:
        boundary = date(today.year - years, today.month, 28)
    return {"param": "birthdate", "op": op, "value": boundary.isoformat()}

def parse_query_to_fhir(query: str):
    gender = extract_gender(query)
    cond = extract_condition(query)
    age_c = extract_age_constraint(query)

    params = []
    if age_c:
        b = age_to_birthdate_filter(age_c["op"], age_c["value"])
        reverse = {"gt":"lt","ge":"le","lt":"gt","le":"ge","eq":"eq"}
        params.append((b["param"], reverse[b["op"]] + b["value"]))
    if gender:
        params.append(("gender", gender))
    if cond:
        params.append(("has:Condition:patient:code", cond["icd10"]))
    base = "/Patient"
    if params:
        q = "&".join(f"{k}={v}" for k, v in params)
        url = f"{base}?{q}"
    else:
        url = base
    return {
        "resource": "Patient",
        "searchParams": [{"name": k, "value": v} for k, v in params],
        "simulatedURL": url,
        "detected": {"gender": gender, "condition": cond, "age": age_c}
    }