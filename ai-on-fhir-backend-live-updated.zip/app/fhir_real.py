import requests
import os

FHIR_BASE = os.getenv("FHIR_BASE", "https://hapi.fhir.org/baseR4")

def _build_params(search_params):
    params = {}
    for p in search_params:
        params[p["name"]] = p["value"]
    return params

def search_patients(search_params, timeout=15):
    params = _build_params(search_params)
    url = f"{FHIR_BASE}/Patient"
    resp = requests.get(url, params=params, timeout=timeout)
    resp.raise_for_status()
    return resp.json()