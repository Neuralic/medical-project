from app.nlp import parse_query_to_fhir
def test_parse_basic():
    m = parse_query_to_fhir("female diabetic patients over 50")
    assert m["resource"] == "Patient"
    assert any(p["name"]=="gender" and p["value"]=="female" for p in m["searchParams"])