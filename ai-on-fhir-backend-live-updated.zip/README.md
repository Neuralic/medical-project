# AI on FHIR – Backend (Live HAPI FHIR Integration)

This backend turns natural language queries into FHIR search parameters and queries a live FHIR server.

## Warning
- The default FHIR server is the public HAPI test server at https://hapi.fhir.org/baseR4.
- Do not send real PHI to public sandboxes. Use only synthetic/test data there.
- For production use a private FHIR server and SMART on FHIR / OAuth2 authentication.

## Quick Start (local)
1. Create a virtualenv and install:
   python -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt

2. (Optional) Point to a different FHIR server:
   export FHIR_BASE="https://your.fhir.server/baseR4"

3. Start the FastAPI app:
   uvicorn app.main:app --reload

4. Test:
   curl -X POST http://127.0.0.1:8000/parse -H "Content-Type: application/json" -d '{"query":"female diabetic patients over 50"}'

The server will call the configured FHIR server and return a FHIR Bundle (if available).

## Notes
- Use FHIR_BASE env var to point to private servers.
- Add SMART on FHIR / OAuth2 for secure connections to EHRs.
- Add caching, retries, and rate limiting for production resilience.